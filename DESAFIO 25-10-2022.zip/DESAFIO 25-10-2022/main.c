#include "desafio.h"
#include <stdio.h>

int main()
{
    List *list1 = List_create(3);
    List_add_first(list1, 20);
    List_add_first(list1, 30);
    List_add_first(list1, 40);
    List *list2 = List_create(3);
    List_add_first(list2, 22);
    List_add_first(list2, 33;
    List_add_first(list2, 44);


    List_two_merge(list1,list2);


    return 0;
}